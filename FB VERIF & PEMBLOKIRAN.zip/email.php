<?php
$emailku = 'EMAILKAMU@gmail.com'; // GANTI EMAIL KAMU DISINI
?>